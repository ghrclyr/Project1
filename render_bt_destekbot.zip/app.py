
from flask import Flask, request, jsonify
import openai
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
CORS(app)
app.config['JWT_SECRET_KEY'] = 'super-secret-key'
jwt = JWTManager(app)

# Load OpenAI API Key from environment variable
openai.api_key = os.getenv("OPENAI_API_KEY")

if not openai.api_key:
    raise ValueError("OpenAI API anahtarı bulunamadı. Lütfen çevre değişkenlerini kontrol edin.")

# Temporary in-memory storage for users
users = {}

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"message": "Kullanıcı adı ve şifre gereklidir."}), 400

    if username in users:
        return jsonify({"message": "Kullanıcı zaten mevcut."}), 400

    users[username] = generate_password_hash(password)
    return jsonify({"message": "Kayıt başarılı."})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"message": "Kullanıcı adı ve şifre gereklidir."}), 400

    if username not in users or not check_password_hash(users[username], password):
        return jsonify({"message": "Geçersiz kimlik bilgileri."}), 401

    access_token = create_access_token(identity=username)
    return jsonify({"access_token": access_token})

@app.route('/ask', methods=['POST'])
@jwt_required()
def ask_question():
    data = request.json
    question = data.get('question')

    if not question:
        return jsonify({"message": "Soru gereklidir."}), 400

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Sen BT DestekBot olarak yardım sağlayan bir asistansın."},
            {"role": "user", "content": f"Soru: {question}"}
        ]
    )
    answer = response['choices'][0]['message']['content']
    return jsonify({"answer": answer})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
